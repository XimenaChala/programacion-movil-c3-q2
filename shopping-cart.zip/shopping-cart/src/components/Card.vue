<template>
    <ion-card>
      <ion-card-header>
        <ion-card-title>{{ title }}</ion-card-title>
      </ion-card-header>
      <ion-card-content>
        {{ content }}
      </ion-card-content>
    </ion-card>
  </template>
  
  <script lang="ts">
  import { IonCard, IonCardHeader, IonCardTitle, IonCardContent } from '@ionic/vue';
  import { defineComponent } from 'vue';
  
  export default defineComponent({
    name: 'Card',
    props: {
      title: {
        type: String,
        required: true
      },
      content: {
        type: String,
        required: true
      }
    },
    components: {
      IonCard,
      IonCardHeader,
      IonCardTitle,
      IonCardContent
    }
  });
  </script>