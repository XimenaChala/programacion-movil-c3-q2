<template>
    <ion-input :placeholder="placeholder"></ion-input>
  </template>
  
  <script lang="ts">
  import { IonInput } from '@ionic/vue';
  import { defineComponent } from 'vue';
  
  export default defineComponent({
    name: 'Input',
    props: {
      placeholder: {
        type: String,
        required: true
      }
    },
    components: {
      IonInput
    }
  });
  </script>
  