<template>
    <div class="loader" v-if="isLoading">Loading...</div>
  </template>
  
  <script>
  export default {
    props: {
      isLoading: {
        type: Boolean,
        default: false
      }
    }
  };
  </script>
  
