<template>
    <div v-if="isVisible" class="modal">
      <div class="modal-content">
        <span class="close" @click="closeModal">&times;</span>
        <slot></slot>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        isVisible: false
      };
    },
    methods: {
      closeModal() {
        this.isVisible = false;
        this.$emit('close');
      },
      openModal() {
        this.isVisible = true;
      }
    }
  };
  </script>
  
 