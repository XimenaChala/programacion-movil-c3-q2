<template>
    <ion-button @click="onClick">
      {{ text }}
    </ion-button>
  </template>
  
  <script lang="ts">
  import { IonButton } from '@ionic/vue';
  import { defineComponent } from 'vue';
  
  export default defineComponent({
    name: 'Button',
    props: {
      text: {
        type: String,
        required: true
      },
      onClick: {
        type: Function,
        required: true
      }
    },
    components: {
      IonButton
    }
  });
  </script>