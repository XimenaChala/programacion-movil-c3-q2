<template>
    <div class="dropdown">
      <button @click="toggleDropdown">{{ selected }}</button>
      <div v-if="isOpen" class="dropdown-content">
        <div v-for="option in options" :key="option" @click="selectOption(option)">
          {{ option }}
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    props: {
      options: Array,
      value: String
    },
    data() {
      return {
        isOpen: false,
        selected: this.value
      };
    },
    methods: {
      toggleDropdown() {
        this.isOpen = !this.isOpen;
      },
      selectOption(option) {
        this.selected = option;
        this.isOpen = false;
        this.$emit('input', option);
      }
    }
  };
  </script>
  
  