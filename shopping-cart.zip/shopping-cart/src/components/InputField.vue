<template>
    <div class="input-field">
      <label :for="id">{{ label }}</label>
      <input :id="id" :type="type" v-model="value" @input="updateValue" />
    </div>
  </template>
  
  <script>
  export default {
    props: {
      label: String,
      type: {
        type: String,
        default: 'text'
      },
      value: String,
      id: String
    },
    methods: {
      updateValue(event) {
        this.$emit('input', event.target.value);
      }
    }
  };
  </script>
  
 