<template>
    <span class="badge" :class="type">{{ text }}</span>
  </template>
  
  <script>
  export default {
    props: {
      text: String,
      type: {
        type: String,
        default: 'default'
      }
    }
  };
  </script>
  
  