<template>
    <ion-toggle
      :checked="checked"
      @ionChange="onChange"
    >
      {{ label }}
    </ion-toggle>
  </template>
  
  <script lang="ts">
  import { IonToggle } from '@ionic/vue';
  import { defineComponent } from 'vue';
  
  export default defineComponent({
    name: 'Checkbox',
    props: {
      label: {
        type: String,
        required: true
      },
      checked: {
        type: Boolean,
        required: true
      },
      onChange: {
        type: Function,
        required: true
      }
    },
    components: {
      IonToggle
    }
  });
  </script>