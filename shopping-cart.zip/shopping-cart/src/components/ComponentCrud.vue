<template>
    <ion-page>
      <ion-header>
        <ion-toolbar>
          <ion-title>Lista de Tareas</ion-title>
        </ion-toolbar>
      </ion-header>
  
      <ion-content>
        <!-- Entrada para agregar nueva tarea -->
        <ion-item>
          <ion-label position="floating">Nueva Tarea</ion-label>
          <ion-input placeholder="Descripción de la tarea" v-model="newTask.description"></ion-input>
        </ion-item>
  
        <!-- Selector de prioridad -->
        <ion-item>
          <ion-label>Prioridad</ion-label>
          <ion-select v-model="newTask.priority" placeholder="Selecciona">
            <ion-select-option value="alta">Alta</ion-select-option>
            <ion-select-option value="media">Media</ion-select-option>
            <ion-select-option value="baja">Baja</ion-select-option>
          </ion-select>
        </ion-item>
  
        <!-- Checkbox para mostrar completadas -->
        <ion-item>
          <ion-label>Mostrar Completadas</ion-label>
          <ion-checkbox v-model="showCompleted"></ion-checkbox>
        </ion-item>
  
        <!-- Botón para agregar tarea -->
        <ion-button expand="block" @click="addTask">Agregar Tarea</ion-button>
  
        <!-- Lista de tareas -->
        <ion-list>
          <ion-item v-for="(task, index) in filteredTasks" :key="index">
            <ion-label>
              <h2>{{ task.description }}</h2>
              <p>Prioridad: {{ task.priority }}</p>
            </ion-label>
            <ion-checkbox slot="start" v-model="task.completed"></ion-checkbox>
            <ion-button slot="end" color="danger" @click="deleteTask(index)">Eliminar</ion-button>
          </ion-item>
        </ion-list>
  
        <!-- Mensajes de confirmación -->
        <ion-toast :isOpen="showToast" message="Tarea agregada" duration="1500" @didDismiss="showToast = false" />
        <ion-toast :isOpen="showDeleteToast" message="Tarea eliminada" duration="1500" @didDismiss="showDeleteToast = false" />
      </ion-content>
    </ion-page>
  </template>
  
  <script>
  import { ref, computed } from 'vue';
  import {
    IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonItem, IonLabel, IonInput,
    IonButton, IonList, IonCheckbox, IonSelect, IonSelectOption, IonToast
  } from '@ionic/vue';
  
  export default {
    components: {
      IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonItem, IonLabel, IonInput,
      IonButton, IonList, IonCheckbox, IonSelect, IonSelectOption, IonToast
    },
    setup() {
      const tasks = ref([
        { description: 'Comprar leche', priority: 'baja', completed: false },
        { description: 'Lavar la ropa', priority: 'media', completed: true },
        { description: 'Ir al gimnasio', priority: 'alta', completed: false }
      ]);
      const newTask = ref({ description: '', priority: 'baja', completed: false });
      const showToast = ref(false);
      const showDeleteToast = ref(false);
      const showCompleted = ref(false);
  
      const filteredTasks = computed(() => {
        return tasks.value.filter(task => showCompleted || !task.completed);
      });
  
      function addTask() {
        if (newTask.value.description.trim()) {
          tasks.value.push({ ...newTask.value });
          newTask.value = { description: '', priority: 'baja', completed: false };
          showToast.value = true;
        }
      }
  
      function deleteTask(index) {
        tasks.value.splice(index, 1);
        showDeleteToast.value = true;
      }
  
      return {
        tasks,
        newTask,
        showToast,
        showDeleteToast,
        showCompleted,
        filteredTasks,
        addTask,
        deleteTask
      };
    }
  };
  </script>
  
  <style scoped>
  ion-item {
    margin-bottom: 10px;
  }
  ion-checkbox {
    margin-right: 15px;
  }
  </style>
  